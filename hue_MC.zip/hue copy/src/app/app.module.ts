import { NewsService } from './services/news.service';
import { MonitorService } from './services/monitor.service';
import { UserService } from './services/user.service';
import { GoogleAuthService } from 'ng-gapi/lib/GoogleAuthService';
import { CalendarService } from './services/calendar.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { LightsComponent } from './lights/lights.component';
import { HueService } from './hue.service';
import { LightItemComponent } from './lights/light-item/light-item.component';
import { TimerComponent } from './tools/timer/timer.component';
import { BookComponent } from './story/book/book.component';
import { NavComponent } from './nav/nav.component';
import { AppRoutingModule } from './/app-routing.module';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { PortfolioService } from './services/portfolio.service';
import { CryptoPipe } from './crypto.pipe';
import { HealthComponent } from './health/health/health.component';
import { CalendarComponent } from './calendar/calendar.component';
import {GoogleApiModule, NG_GAPI_CONFIG} from "ng-gapi";
import { GreetingComponent } from './greeting/greeting.component';
import { FoodComponent } from './food/food.component';
import { WeatherComponent } from './weather/weather.component';
import { WeatherService } from './services/weather.service';
import { DebugComponent } from './debug/debug.component';
import { DebugService } from './services/debug.service';
import { DateTimeComponent } from './date-time/date-time.component';
import { NewsComponent } from './news/news.component';

let gapiClientConfig = {
  client_id: "416692708174-phsv2jpk6funpkg8qcm0193j6trh1f4h.apps.googleusercontent.com",
  discoveryDocs: ["https://analyticsreporting.googleapis.com/$discovery/rest?version=v4"],
  scope: [
      "https://www.googleapis.com/auth/calendar.readonly"
  ].join(" ")
};

@NgModule({
  declarations: [
    AppComponent,
    LightsComponent,
    LightItemComponent,
    TimerComponent,
    BookComponent,
    NavComponent,
    PortfolioComponent,
    CryptoPipe,
    HealthComponent,
    CalendarComponent,
    GreetingComponent,
    FoodComponent,
    WeatherComponent,
    DebugComponent,
    DateTimeComponent,
    NewsComponent
    ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    GoogleApiModule.forRoot({
      provide: NG_GAPI_CONFIG,
      useValue: gapiClientConfig
  }),
  ],
  providers: [HueService, PortfolioService, WeatherService, CalendarService, UserService, NewsService, MonitorService, DebugService, {provide: Window, useValue: window }],
  bootstrap: [AppComponent]
})
export class AppModule { }
