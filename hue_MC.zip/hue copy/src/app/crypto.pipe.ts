import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'cryptofilter'
})
export class CryptoPipe implements PipeTransform {

  transform(coins): any {
    if (coins) {
      return coins.filter(coin => (coin.symbol == "BTC" || coin.symbol == "ETH" || coin.symbol == "LTC" || coin.symbol == "DASH"));
    }
  }

}
