import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'date-time',
  templateUrl: './date-time.component.html',
  styleUrls: ['./date-time.component.scss']
})
export class DateTimeComponent implements OnInit {

  private date;
  private time;
  private days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturay"]
  private months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  constructor() { }

  ngOnInit() {
    var today = new Date();
    this.date = this.days[today.getDay()] + ", " + this.months[today.getMonth()] + " " + today.getFullYear();
    this.time = today.getHours() + ":" + today.getMinutes();
  }

}
