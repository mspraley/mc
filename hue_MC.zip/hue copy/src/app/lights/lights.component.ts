import { Component, OnInit } from '@angular/core';

import {HueService} from '../hue.service';

@Component({
  selector: 'lights',
  templateUrl: './lights.component.html',
  styleUrls: ['./lights.component.scss']
})
export class LightsComponent implements OnInit {

  private lights;
  private sensors;
  private rooms = ["Bedroom", "Living", "Kitchen", "Office"]

  constructor(private hueService: HueService) { }

  ngOnInit() {
    this.hueService.getBridge().subscribe(data => {
        if (!data) {
          this.hueService.getLights().subscribe(lights => {
            this.lights = Object.values(lights);
            this.hueService.setLights(this.lights);
          });
          
          this.hueService.getSensors().subscribe(sensors => {
            this.sensors = Object.values(sensors);
            this.sensors = this.sensors.filter(sensor => sensor.name == "Samantha");
          });
          setInterval(() => {    
            this.hueService.getSensors().subscribe(sensors => {
              this.sensors = Object.values(sensors);
              this.sensors = this.sensors.filter(sensor => sensor.name == "Samantha");
              this.hueService.setSensors(this.sensors);
            });
          },1500);
        }
    });
  }

}
