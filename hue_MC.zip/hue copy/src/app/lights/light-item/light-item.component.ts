import { Component, OnInit, Input } from '@angular/core';
import { HueService } from '../../hue.service';

@Component({
  selector: 'light-item',
  templateUrl: './light-item.component.html',
  styleUrls: ['./light-item.component.scss']
})
export class LightItemComponent implements OnInit {

  @Input() light;
  @Input() lightnum;

  constructor(private hueService: HueService) { }

  ngOnInit() {
  }

  toggleLight(light, event) {
    this.hueService.toggleLight(this.light, this.lightnum + 1).subscribe(data => {
      this.light.state.on = !this.light.state.on;
    })
  }
}