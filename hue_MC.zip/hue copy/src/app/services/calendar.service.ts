import { MonitorService } from './monitor.service';
import { UserService } from './../services/user.service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class CalendarService {

  constructor(private http: HttpClient, private userService: UserService){}

  getCalendarList(): Observable<any> {
    let authToken = sessionStorage.getItem(UserService.SESSION_STORAGE_KEY);
    let headers = new HttpHeaders({'Authorization': `Bearer ${authToken}`});

      return this.http.get<any>("https://www.googleapis.com/calendar/v3/users/me/calendarList", {headers: headers}).flatMap((data) => {
        let primaryCalendar = data.items.filter(item => item.primary == true);
        var today = new Date().toISOString();
        var tomorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000).toISOString();
        return this.http.get<any>("https://www.googleapis.com/calendar/v3/calendars/mattdspraley@gmail.com/events?timeMin=" + today + "&timeMax=" + tomorrow, {headers: headers});  
      });
    }
}
