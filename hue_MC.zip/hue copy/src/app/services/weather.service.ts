import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class WeatherService {

  constructor(private http: HttpClient) { }

  getWeather(): Observable<any>{
    return this.http.get("http://api.openweathermap.org/data/2.5/weather?q=Atlanta&units=imperial&APPID=5b1832aaf112a201f7b18e44c3dc5aad");
  }

}
