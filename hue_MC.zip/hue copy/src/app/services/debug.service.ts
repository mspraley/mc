import { LightItemComponent } from './../lights/light-item/light-item.component';
import { Injectable } from '@angular/core';

@Injectable()
export class DebugService {

  items = [];

  constructor() { }

  addItem(item) {
    this.items.push(item);
  }

}
