import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class HealthService {

  constructor(private http: HttpClient) { }

  getHeartRate() {
    var token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0RkRZRjkiLCJhdWQiOiIyMjhKQkMiLCJpc3MiOiJGaXRiaXQiLCJ0eXAiOiJhY2Nlc3NfdG9rZW4iLCJzY29wZXMiOiJyc29jIHJzZXQgcmFjdCBybG9jIHJ3ZWkgcmhyIHJudXQgcnBybyByc2xlIiwiZXhwIjoxNTA0MjM1MDAzLCJpYXQiOjE1MDM2MzAyMDN9.CwUuSt5jhYvqnZrw9zSyhNtE5bqNW5FyRzZvatl64_4";
    
    this.http.get('https://api.fitbit.com/1/user/-/activities/heart/date/today/1d/1sec/time/00:00/00:01.')
  }

}
