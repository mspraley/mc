import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class MonitorService {

  constructor(private window: Window, private router: Router) { }

  monitorForCalls() {
    console.log("we are monitoring");
    // this.window.handleCall = function(event) {
    //   console.log(JSON.parse(event));
    // }
    // let monitorService = this;
    // this.window.changePage = function(page, angular = monitorService) {
    //   console.log("moving to page " + page);
    //   angular.router.navigate([page]);
    // }
  }

}
