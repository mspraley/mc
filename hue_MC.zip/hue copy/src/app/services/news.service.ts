import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class NewsService {

  constructor(private http: HttpClient) { }

  getNews() {
    return this.http.get<any>("https://newsapi.org/v2/top-headlines?country=us&apiKey=2046473e93354962b55158438a80c6fb");
  }

}
