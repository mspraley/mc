import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class PortfolioService {

  private marketcapURL = "https://api.coinmarketcap.com/v1/ticker/?limit=20";
  private stockURL = "";
  private stocks = ["aapl", "mu", "msft", "intc", "sq", "hd", "tsem", "iau", "gld", "fmc", ""];


  constructor(private http: HttpClient) { }

  buildStockURL() {
    var symbols = this.stocks.join();
    this.stockURL = 'https://api.iextrading.com/1.0/stock/market/batch?symbols=' + symbols + '&types=quote,news,chart&range=1m&last=5';
  }

  getStocks(): Observable<any> {
    this.buildStockURL();
    return this.http.get<[any]>(this.stockURL);
  }

  getCoins(): Observable<any> {
    return this.http.get<[any]>(this.marketcapURL);
  }
}
