import { Component, OnInit } from '@angular/core';
import { NewsService } from '../services/news.service';

@Component({
  selector: 'news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {

  private articles;
  private articleCount = 0;
  private currentArticle = '';
  private fade = false;

  constructor(private newsService: NewsService) { }

  ngOnInit() {
    this.newsService.getNews().subscribe(results => {
      this.articles = results.articles;
    })

    setInterval(() => {
      if(this.articleCount >= 20) {
        this.articleCount = 0;
      }
      this.fade = true;
      setTimeout(() => {
        this.currentArticle = this.articles[this.articleCount++];
        this.fade = false;
      },2000);
    }, 7000)
  }


}
