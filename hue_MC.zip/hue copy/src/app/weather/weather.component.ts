import { MonitorService } from './../services/monitor.service';
import { WeatherService } from './../services/weather.service';
import { Component, OnInit, ApplicationRef } from '@angular/core';

@Component({
  selector: 'weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.scss']
})
export class WeatherComponent implements OnInit {

  private  dayTime; 
  private forecast;
  private nextDays = [];

  constructor(private weatherService: WeatherService, private monitorService: MonitorService, private window: Window) { }

  ngOnInit() {
    //this.monitorService.monitorForCalls();
    let weekday =  ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    this.dayTime = weekday[new Date().getDay()];

    // try {
    //   window.webkit.messageHandlers.greeting.postMessage("Doesn't look like anything to me");
    // } catch(err) {
    //   console.log('The native context does not exist yet');
    // }
    // this.window.handleCall = function(this, event) {
    // var weatherJSON = JSON.parse(event);
    // console.log(JSON.parse(event));
    //   var currentWeather = weatherJSON.messageBody.directives[2].payload;
    //   this.currentTemp = currentWeather.currentWeather;
    //   this.currentDescription =  currentWeather.currentWeather;
    //   console.log(this.currentDescription);
    // }

    this.weatherService.getWeather().subscribe(forecast => {
      this.forecast = forecast;
      setTimeout(() => { 
      }, 3000)
    })
    

  }

}
