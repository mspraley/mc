import { STOCKS } from './../../assets/stocks';
import { PortfolioService } from './../services/portfolio.service';
import { Component, OnInit } from '@angular/core';
import {trigger, transition, state, style, animate, query, stagger} from '@angular/animations';

@Component({
  selector: 'portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.scss'],
  animations: [
    trigger('listAnimation', [
      transition('* => *', [ // each time the binding value changes
        query(':enter', [
          style({ opacity: 0, transform: 'translateX(-10px)' }),
          stagger(100, [
            animate('0.5s', style({ opacity: 1, transform: 'translateX(0px)'}))
          ])
        ])
      ])
    ]),
    trigger('flyInOut', [
      state('in', style({transform: 'translateX(0px)',  opacity: 1})),
      transition('void => *', [
        style({transform: 'translateX(10px)', opacity: 0}),
        animate(300)
      ])
    ])
  ]
})
export class PortfolioComponent implements OnInit {

  private crypto;
  private bitcoinprice;
  private stocks;
  private stockTotal = 0;

  constructor(private portfolioService: PortfolioService) { }

  ngOnInit() {
    this.portfolioService.getStocks().subscribe(stocks => {
      if (stocks) {
        this.stocks = Object.values(stocks);
        for(let stock of STOCKS) {
          for(let stockinner of this.stocks) {
            if (stock.name == stockinner.quote.symbol.toLowerCase()) {
              this.stockTotal += (stockinner.quote.latestPrice * stock.amount);
            }
          }
        }
      }
    })
    this.portfolioService.getCoins().subscribe(coins => {
      if (coins) {
          this.crypto = coins;
          this.bitcoinprice = coins.filter(coin => coin.symbol == "BTC")[0];
          try {
            let action = this.bitcoinprice.percent_change_1h > 0 ? "up!" : "down";
            //let portfolioText = "Bitcoin is " + action + ". With a " + this.bitcoinprice.percent_change_1h + "% change in the last hour";
            //window.webkit.messageHandlers.greeting.postMessage(portfolioText);
          } catch(err) {
            console.log('The native context does not exist yet');
          }
      }
    });
    setInterval(() => {    
      this.portfolioService.getCoins().subscribe(coins => {
      if (coins) {
          this.crypto = coins;
          this.bitcoinprice = coins.filter(coin => coin.symbol == "BTC")[0];
      }
  }); 
}, 60000);

  }
}
