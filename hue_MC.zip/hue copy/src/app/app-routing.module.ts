import { DebugComponent } from './debug/debug.component';
import { WeatherComponent } from './weather/weather.component';
import { CalendarComponent } from './calendar/calendar.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { LightsComponent } from './lights/lights.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GreetingComponent } from './greeting/greeting.component';

const routes: Routes = [
  { path: 'lights', component: LightsComponent },
  { path: 'portfolio', component: PortfolioComponent },
  { path: 'calendar', component: CalendarComponent },
  { path: 'weather', component: WeatherComponent },
  { path: 'greeting', component: GreetingComponent },
  { path: 'debug', component: DebugComponent }
];

@NgModule({
  exports: [ RouterModule ],
  imports: [ RouterModule.forRoot(routes)]
})

export class AppRoutingModule {}