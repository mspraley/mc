import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/mergeMap';
import { Router } from '@angular/router';

@Injectable()
export class HueService {

  private bridgeURL = 'https://www.meethue.com/api/nupnp';
  private bridgeIP;
  private username;
  private apiURL;
  private results = {};
  private sensors;
  private lights;

  constructor(private http: HttpClient, private router: Router) {
  }

  getBridge(): Observable<any> {
    if (localStorage.getItem('apiURL') == null) {
    return this.http.get(this.bridgeURL).flatMap((data) => {
      this.bridgeIP = data[0]['internalipaddress'];   
      this.apiURL = "http://" + this.bridgeIP + "/api";
      return this.http.post(this.apiURL, {devicetype: "samantha"});  
    }).flatMap((user) => {
      this.apiURL = this.apiURL + "/" + user[0].success.username;
      localStorage.setItem('apiURL', this.apiURL);
      return of(true);
    })
    } else {
      return of(false);
    }
  }

  getLights(): Observable<[any]> {
    return this.http.get<[any]>(localStorage.getItem('apiURL') + "/lights");
  }

  getSensors(): Observable<[any]> {
      return this.http.get<[any]>(localStorage.getItem('apiURL') + "/sensors");
  }

  setLights(lights) {
    this.lights = lights;
    //for future
    //localStorage.setItem('lightState-' + new Date().getTime(), JSON.stringify(lights));
  }

  setSensors(sensors): Boolean {             
    var mainSensor = Object.values(sensors).filter(sensor => sensor.name == "Samantha");
    this.sensors = mainSensor;
    if (this.sensors[0].state.presence) {
      return true;
    } else {
      return false;
    }
  }

  oneLight(lightIndex, flag): Observable<any> {
    return this.http.put(localStorage.getItem('apiURL') + '/lights/' + lightIndex + '/state/', {'on' :flag});
  }

  allLights(flag) {
    this.lights.forEach((light,index) => {
      this.http.put(localStorage.getItem('apiURL') + '/lights/' + index + '/state/', {'on' :flag}).subscribe((success) => {
        console.log("light successfully changed");
      })
    });
  }

  toggleLight(light, lightnum): Observable<any> {
    return this.http.put(localStorage.getItem('apiURL') + '/lights/' + lightnum + '/state/', {'on' : !light.state.on});
  }
}
