import { MonitorService } from './services/monitor.service';
import { Router } from '@angular/router';
import { Component } from '@angular/core';
import { HueService } from './hue.service';
import { DebugService } from './services/debug.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  detected = false;
  inside = false;

  constructor(private hueService: HueService, private debugService: DebugService, private router: Router, private monitorService: MonitorService) {
    
  }

  ngOnInit() {
    this.monitorService.monitorForCalls();
    this.hueService.getLights().subscribe(lights => {
      var lightsArray = Object.values(lights);
      this.hueService.setLights(lightsArray);
     // this.debugService.addItem("Light data saved. " + lightsArray.length + " recorded.")
    });

    setInterval(() => {    
      this.hueService.getLights().subscribe(lights => {
        var lightsArray = Object.values(lights);
        this.hueService.setLights(lightsArray);
       // this.debugService.addItem("Light data saved. " + lightsArray.length + " recorded.")
      });
    },60000);

    setInterval(() => {
      this.hueService.getSensors().subscribe(sensors => {
        var presence = this.hueService.setSensors(sensors);
        if (presence) {
          if (!this.detected) {
            this.debugService.addItem("Presence last detected " + new Date())
            this.router.navigate(['greeting']);
            this.detected = true;
            this.inside = !this.inside;
            this.hueService.allLights(true);

            if (this.inside == false) {
              setTimeout(() => {
                this.detected = false;
                this.hueService.allLights(true);
              }, 65000);
            }
          }
        }   
      });
    }, 5000);

  }
}
