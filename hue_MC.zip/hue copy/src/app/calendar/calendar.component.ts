import { CalendarService } from './../services/calendar.service';
import { UserService } from './../services/user.service';
import { Component, OnInit } from '@angular/core';
import {trigger, transition, style, animate, query, stagger} from '@angular/animations';

@Component({
  selector: 'calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss'],
  animations: [
    trigger('listAnimation', [
      transition('* => *', [ // each time the binding value changes
        query(':enter', [
          style({ opacity: 0, transform: 'translateX(10px)' }),
          stagger(100, [
            animate('0.4s', style({ opacity: 1, transform: 'translateX(0px)'}))
          ])
        ])
      ])
    ])
  ]

})
export class CalendarComponent implements OnInit {

  private dailyEvents = [];

  constructor(private userService: UserService, private calendarService: CalendarService) { }

  ngOnInit() {
    if (this.userService.isUserSignedIn()) {
      this.calendarService.getCalendarList().subscribe(calendar => {
        this.dailyEvents = calendar.items;
        console.log(this.dailyEvents);
        let eventText = "It looks like you have " + this.dailyEvents.length + " events today";
        //window.webkit.messageHandlers.events.postMessage(eventText);
      }, (error) => {
        this.userService.signIn();
      })
    }
    }
  }
