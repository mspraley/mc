import { MonitorService } from './../services/monitor.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import {trigger, transition, state, style, animate, query, stagger} from '@angular/animations';

@Component({
  selector: 'app-greeting',
  templateUrl: './greeting.component.html',
  styleUrls: ['./greeting.component.scss'],
  animations: [
    trigger('flyInOut', [
      state('in', style({opacity: 1})),
      transition('void => *', [
        style({opacity: 0}),
        animate(200)
      ]),
      transition('* => void', [
        style({opacity: 1}),
        animate(500)
      ])
    ])
  ]
})
export class GreetingComponent implements OnInit {

  constructor(private router: Router, private monitorService: MonitorService) { }

  ngOnInit() {
    let greetingText = "Cheerio! Welcome back Matt.";
    // try {
    //   window.webkit.messageHandlers.command.postMessage(greetingText);
    // } catch(err) {
    //   console.log('The native context does not exist yet');
    // }
    // setTimeout(() => { 
    //   this.router.navigate(['lights']);
    // }, 3000);
  }

}
