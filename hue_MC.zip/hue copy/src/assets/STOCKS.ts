export const STOCKS = [
    {
      name: "aapl",
      amount: 6
    }, {
      name: "mu",
      amount: 50000
    },{
      name: "msft",
      amount: 5
    },
    {
      name: "intc",
      amount: 2
    },
    {
      name: "sq",
      amount: 4
    },
    {
      name: "hd",
      amount: 3
    },
    {
      name: "tsem",
      amount: 10
    },
    {
      name: "iau",
      amount: 8
    },
    {
      name: "gld",
      amount: 1
    },
    {
      name: "fmc",
      amount: 1
    }]
