import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import { Router } from '@angular/router';
import { API } from "../services/api";

@Injectable()
export class HeaderInterceptor implements HttpInterceptor {
  constructor(private router: Router) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    var token =  localStorage.getItem('dnpAuth');
    var base = API.URL.development
    if (window.location.hostname.indexOf("mcorp3") != -1) {
      base = API.URL.production 
    }
    request = request.clone({
      url: request.url.replace('{base}', base)
    })
    var header = `Bearer ${token}`;
    if (token) {
        request = request.clone({
            setHeaders: {
              Authorization: `Bearer ${token}`
            }
          });
    }
    console.log(request.url);
    return next.handle(request).do(event => {}, err => {
      if(err instanceof HttpErrorResponse){
          console.log("Error Caught By Interceptor");
          if (err.error.status == 401 || err.error.status == 403) {
            localStorage.removeItem('currentUser');
            this.router.navigate(['/login']);
          }
      }
  });
  }
}