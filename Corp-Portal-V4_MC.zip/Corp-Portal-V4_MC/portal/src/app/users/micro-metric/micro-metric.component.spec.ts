import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MicroMetricComponent } from './micro-metric.component';

describe('MicroMetricComponent', () => {
  let component: MicroMetricComponent;
  let fixture: ComponentFixture<MicroMetricComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MicroMetricComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MicroMetricComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
