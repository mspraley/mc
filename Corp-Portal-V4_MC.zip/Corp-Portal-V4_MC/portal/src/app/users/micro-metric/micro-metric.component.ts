import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'micro-metric',
  templateUrl: './micro-metric.component.html',
  styleUrls: ['./micro-metric.component.scss']
})
export class MicroMetricComponent implements OnInit {

  @Input() value;
  @Input() title;
  @Input() type;

  constructor() { }

  ngOnInit() {
  }

}
