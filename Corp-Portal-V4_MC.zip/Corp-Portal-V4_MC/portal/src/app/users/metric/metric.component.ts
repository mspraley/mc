import { Component, OnInit, Input } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
@Component({
  selector: 'metric',
  templateUrl: './metric.component.html',
  styleUrls: ['./metric.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({transform: 'translateY(-5px)', opacity: '0'}),
        animate(200)
      ]),
      transition(':leave', [
        animate(100, style({transform: 'translateX(-100px)', opacity: '0'}))
      ])
    ])
  ]
})
export class MetricComponent implements OnInit {

  @Input() data;
  @Input() title;
  mode = "chart";

  constructor() { }

  ngOnInit() {
  }

  toggleMode(value) {
    this.mode = value;
  }
}
