import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

  dataSource;
  id = 'chart1';
  width = 280;
  height = 250;
  type = 'line';
  dataFormat = 'json';
  title = 'Angular4 FusionCharts Sample';

  constructor() { 
    this.dataSource = {
      "chart": {
          "theme": "fint",
          "bgcolor": "FFFFFF",
          "showalternatehgridcolor": "0",
          "plotbordercolor": "00ff00",
          "paletteColors": "#14a7f3",
          "plotborderthickness": "3",
          "showvalues": "0",
          "xAxisLineColor": "#ffffff",
          "animation" : "0"
      },
      "data": [
          {
              "value": "2"
          },
          {
              "value": "2"
          },
          {
              "value": "2"
          },
          {
              "value": "2"
          },
          {
              "value": "2"
          }
      ]
  }
  }

  ngOnInit() {
  }

}
