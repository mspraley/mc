import { Component, OnInit, Input } from '@angular/core';
import { API } from "../../services/api";
import { UserService } from '../../services/user/user-service.service';
import { DomSanitizer } from '@angular/platform-browser';
import {Location} from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'appview',
  templateUrl: './appview.component.html',
  styleUrls: ['./appview.component.scss']
})
export class AppviewComponent implements OnInit {

  srcURL;

  constructor(private userService: UserService, private sanitizer:DomSanitizer, private location: Location, private router: Router) { }

  ngOnInit() {
    this.userService.user.subscribe(user => {
      var base = API.URL.development; 
	  if (window.location.hostname.indexOf("mcorp3") != -1) {
	  	 base = API.URL.production
	  }
      let url = API.appview.appviewURL.replace('{mcpId}', user.userPrivate.uid);
      url = url.replace('{base}', base);
      url = url.replace('{token}', localStorage.getItem('dnpAuth'));
      this.srcURL = this.sanitizer.bypassSecurityTrustResourceUrl(url);
    });
  }

  close() {
    this.location.back()
    //this.router.navigate(['/user/', ]);
  }

}
