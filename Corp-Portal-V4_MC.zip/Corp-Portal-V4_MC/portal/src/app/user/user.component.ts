import { Component, OnInit, HostListener } from '@angular/core';
import { UserService } from '../services/user/user-service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  user;
  contact;
  userID;
  dataLoaded = false;

  constructor(private route: ActivatedRoute, private userService: UserService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.userID = +params['id'];
      this.dataLoaded = false;

      this.userService.getUser(this.userID).subscribe(data =>{

      });
      this.userService.getEnrollment(this.userID).subscribe(data => {
      });
      this.userService.getBatch(this.userID).subscribe(data => {
      });
      this.userService.getLedger(this.userID).subscribe(data => {
      });
      this.userService.getUserContact(this.userID);
   });

   this.userService.user.subscribe(user => {
    this.user = user;
    this.dataLoaded = true;
    }, error => {
      localStorage.removeItem('currentUser');
    })


  this.userService.contact.subscribe(data => {
    this.contact = data;
    }, error => {
      localStorage.removeItem('currentUser');
    })
  }
}
