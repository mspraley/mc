import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCashflowComponent } from './user-cashflow.component';

describe('UserCashflowComponent', () => {
  let component: UserCashflowComponent;
  let fixture: ComponentFixture<UserCashflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserCashflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCashflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
