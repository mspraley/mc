import { Component, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { UserService } from '../../services/user/user-service.service';

@Component({
  selector: 'app-user-cashflow',
  templateUrl: './user-cashflow.component.html',
  styleUrls: ['./user-cashflow.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({transform: 'translateY(-5px)', opacity: '0'}),
        animate(200)
      ]),
      transition(':leave', [
        animate(100, style({transform: 'translateX(-100px)', opacity: '0'}))
      ])
    ])
  ]
})
export class UserCashflowComponent implements OnInit {

  payperiods = [];
  ledger = [];
  flow = 1;


  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.user.subscribe(user => {
      this.payperiods = user.dashboard.payPeriods.items;
    })
    this.userService.ledger.subscribe(ledger => {
      this.ledger = ledger;
    })
  }

  toggleFlow(flow) {
    this.flow = flow;
  }

}
