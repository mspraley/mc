import { Component, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { UserService } from '../../services/user/user-service.service';

@Component({
  selector: 'app-user-banking',
  templateUrl: './user-banking.component.html',
  styleUrls: ['./user-banking.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({transform: 'translateY(-5px)', opacity: '0'}),
        animate(200)
      ]),
      transition(':leave', [
        animate(100, style({transform: 'translateX(-100px)', opacity: '0'}))
      ])
    ])
  ]
})
export class UserBankingComponent implements OnInit {

  accounts;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.user.subscribe(user =>{
      this.accounts = user.accounts.items;
    })
  }

}
