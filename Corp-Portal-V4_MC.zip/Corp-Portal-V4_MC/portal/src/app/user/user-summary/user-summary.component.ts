import { Component, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { UserService } from '../../services/user/user-service.service';

@Component({
  selector: 'app-user-summary',
  templateUrl: './user-summary.component.html',
  styleUrls: ['./user-summary.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({transform: 'translateY(-5px)', opacity: '0'}),
        animate(200)
      ]),
      transition(':leave', [
        animate(100, style({transform: 'translateX(-100px)', opacity: '0'}))
      ])
    ])
  ]
})
export class UserSummaryComponent implements OnInit {

  user;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.user.subscribe(user => {
      this.user = user;
    }, error => {
      localStorage.removeItem('currentUser');
    })
  }

}
