import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user/user-service.service';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';

@Component({
  selector: 'user-activity',
  templateUrl: './user-activity.component.html',
  styleUrls: ['./user-activity.component.scss'],
  animations: [
    trigger('deleteOut', [
      transition(':leave', [
        animate(10000, style({transform: 'translateX(-100px)', opacity: '0'}))
      ])
    ])
  ]
})
export class UserActivityComponent implements OnInit {

  activity = [];
  user;
  filterText = "all";
  typeFilter = '';
  filters = [
    {
      name: "All",
      value: ""
    },
    {
      name: "Bills",
      value: "BILL"
    },
    {
      name: "Goals",
      value: "SAVINGS"
    },
    {
      name: "Transfer",
      value: "XFEREXT"
    },
    {
      name: "Fee",
      value: "FEE"
    }
  ]

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.user.subscribe(user => {
      this.user = user;
    })
    let items = this.userService.batch.subscribe(items => {
      if (items) {
        items.forEach(function(item){
          item.transactions.forEach(function(transaction){
            var types = transaction.transaction_id.split(":");
            if (types[0] == "PULL") {
              transaction.action = types[0];
              transaction.actionType = types[2];
            } else {
              transaction.actionType = types[0];
            }
          })
  
        })
      }
      this.activity = items.reverse();
    });
  }

  filterActivity(filter: string) {
    this.filterText = filter;
  }

  toggleActivityType(filter: string) {
    this.typeFilter = filter;
  }

  deleteBatchItem(batchKey, transactionKey, item, batchNumber) { 
    item.isDeleted = true;
    this.userService.deleteBatchItem(batchKey, transactionKey).subscribe(data => {
    var index = this.activity[batchNumber].transactions.indexOf(item);
    this.activity[batchNumber].transactions.splice(index, 1);  
     });
  }

  trackByFn(index, item) {
    return item.transaction_key; // or item.id
  }
}
