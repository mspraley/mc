import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user/user-service.service';

@Component({
  selector: 'user-contact',
  templateUrl: './user-contact.component.html',
  styleUrls: ['./user-contact.component.scss']
})
export class UserContactComponent implements OnInit {

  contact;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.contact.subscribe(data => {
      if (data) {
        this.contact = data;
      }
    });
  }

}
