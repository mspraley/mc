import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'user-metrics',
  templateUrl: './user-metrics.component.html',
  styleUrls: ['./user-metrics.component.scss']
})
export class UserMetricsComponent implements OnInit {

  @Input() user;
  
  constructor() { }

  ngOnInit() {
  }

}
