import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../../../services/user/user-service.service';

@Component({
  selector: 'user-enrollment',
  templateUrl: './user-enrollment.component.html',
  styleUrls: ['./user-enrollment.component.scss']
})
export class UserEnrollmentComponent implements OnInit {

  @Input() mcpID;
  enrollment;
  dataLoaded = false;

  constructor(private userService: UserService) { }

  ngOnInit() {
      this.userService.enrollment.subscribe(data => {
        if (data) {
          this.enrollment = data;
          this.dataLoaded = true;
        }
      });
  }

}
