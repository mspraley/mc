import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserBillDetailComponent } from './user-bill-detail.component';

describe('UserBillDetailComponent', () => {
  let component: UserBillDetailComponent;
  let fixture: ComponentFixture<UserBillDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserBillDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserBillDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
