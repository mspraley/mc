import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { UserService } from '../../../services/user/user-service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'bill-detail',
  templateUrl: './user-bill-detail.component.html',
  styleUrls: ['./user-bill-detail.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({transform: 'translateY(-5px)', opacity: '0'}),
        animate(200)
      ]),
      transition(':leave', [
        animate(100, style({transform: 'translateX(-100px)', opacity: '0'}))
      ])
    ])
  ]
})
export class UserBillDetailComponent implements OnInit {

  instances;
  userID;
  billID;

  constructor(private location: Location, private userService: UserService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.billID = +params['billid'];
   });
   this.userService.bill.subscribe(data => {
      this.instances = data;
   });

    this.userService.user.subscribe(data => {
      this.userID = data.userPrivate.uid;
      this.userService.getBillDetail(this.userID, this.billID);
    });
  }

  onBack() {
    this.location.back();
  }

}
