import { Component, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { UserService } from '../../services/user/user-service.service';
import { LedgerService } from '../../services/ledger/ledger.service';

@Component({
  selector: 'app-user-goals',
  templateUrl: './user-goals.component.html',
  styleUrls: ['./user-goals.component.scss'],
  animations: [
    trigger('flyInOut', [
      transition(':enter', [
        style({transform: 'translateY(-5px)', opacity: '0'}),
        animate(200)
      ]),
      transition(':leave', [
        animate(100, style({transform: 'translateX(-100px)', opacity: '0'}))
      ])
    ]),
    trigger('modalFlyIn', [
      transition(':enter', [
        style({transform: 'translateY(-10px)', opacity: '0'}),
        animate(200)
      ]),
      transition(':leave', [
        animate(200, style({transform: 'translateY(10px)', opacity: '0'}))
      ])
    ]),    trigger('modalStatusFlyIn', [
      transition(':enter', [
        style({transform: 'translateY(100%)'}),
        animate(150)
      ]),
      transition(':leave', [
        animate(150, style({transform: 'translateY(-100%)'}))
      ])
    ])
  ]
})
export class UserGoalsComponent implements OnInit {

  goals = [];
  externalAccounts = [];
  totalContribution= [];
  totalSavings = 0;
  editing = false;
  transferSuccessful = false;
  transferFail = false;
  errorMessage = 'Failed';
  targetType = 0;
  toId = "default";
  fromId;
  transferAmount;
  mcpID;

  constructor(private userService: UserService, private ledgerService: LedgerService) { }

  ngOnInit() {
    this.userService.user.subscribe(user => {
      this.mcpID = user.userPrivate.uid;

      this.externalAccounts = user.accounts.items.filter((account) => 
      (account["dnpFunction"] == "EXTERNAL")
      );

      this.goals = user.goals.items.filter((goal) => 
        (goal["status"] == "OPEN")
      );
      this.totalContribution = user.goals.totalAmount;
      this.totalSavings = 0;
      this.goals.forEach(goal => {
        this.totalSavings += goal.balance;
      })
    })
  }

  initiateTransfer(id) {
    this.editing = true;
    this.fromId = id;
  }

  toggleTransfer() {
    this.editing = false;
    this.fromId = '';
    this.toId = '';
    this.transferAmount = '';
  }

  toggleTargetType(value) {
    this.targetType = value;
  }

  clearData() {
    setTimeout(() => {
      this.editing = false;
      this.transferFail = false;
      this.transferSuccessful = false;
      this.fromId = '';
      this.toId = '';
      this.transferAmount = '';
    }, 3000)
  }

  startTransfer() {
    if (this.targetType == 0) {
      this.ledgerService.transferSub(this.mcpID, parseInt(this.toId), parseInt(this.fromId), parseFloat(this.transferAmount)).subscribe(response => {
        if (!response.payload.data[0].results.errorMessage) {
          this.transferSuccessful = true;
          this.clearData();
        } else {
          this.errorMessage = response.payload.data[0].results.errorMessage;
          this.transferFail = true;
          this.clearData();
        }
      })
    } else {
      this.ledgerService.transferExternal(this.mcpID, parseInt(this.fromId), parseFloat(this.transferAmount)).subscribe(response => {
        if (!response.payload.data[0].results.errorMessage) {
          this.transferSuccessful = true;
          this.clearData();
        } else {
          this.transferFail = true;
          this.errorMessage = response.payload.data[0].results.errorMessage;
          this.clearData()
        }
      })
    }

    
  }

}
