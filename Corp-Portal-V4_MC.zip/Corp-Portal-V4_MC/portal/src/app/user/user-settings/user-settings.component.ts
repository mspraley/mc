import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user/user-service.service';

@Component({
  selector: 'app-user-settings',
  templateUrl: './user-settings.component.html',
  styleUrls: ['./user-settings.component.scss']
})
export class UserSettingsComponent implements OnInit {

  user;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.user.subscribe(user => {
      this.user = user;
    })
  }


  toggleSetting(value) {
    //implement multiple settings later
    this.userService.hardClose(this.user.userPrivate.uid, !this.user.userAccountStatus.hardClosed).subscribe(data => {
      this.user.userAccountStatus.hardClosed = !this.user.userAccountStatus.hardClosed;
    });
  }

}
