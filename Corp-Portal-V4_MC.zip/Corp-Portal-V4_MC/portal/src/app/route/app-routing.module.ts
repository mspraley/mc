import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from '../user/user.component';
import { UserSummaryComponent } from '../user/user-summary/user-summary.component';
import { UserGoalsComponent } from '../user/user-goals/user-goals.component';
import { UserBillsComponent } from '../user/user-bills/user-bills.component';
import { UserCashflowComponent } from '../user/user-cashflow/user-cashflow.component';
import { UsersComponent } from '../users/users.component';
import { BatchesComponent } from '../batches/batches.component';
import { UserBillDetailComponent } from '../user/user-bills/user-bill-detail/user-bill-detail.component';
import { UserBankingComponent } from '../user/user-banking/user-banking.component';
import { EmployersComponent } from '../employers/employers.component';
import { Auth } from '../guards/auth';
import { LoginComponent } from '../login/login.component';
import { HomeComponent } from '../home/home.component';
import { UserSettingsComponent } from '../user/user-settings/user-settings.component';
import { EmployerComponent } from '../employer/employer.component';
import { AppviewComponent } from '../user/appview/appview.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent},
  { path: '', component: HomeComponent, canActivate: [Auth],
  children : [
    { path: '', redirectTo: 'users', pathMatch: 'full' },
    { path: 'users', component: UsersComponent, canActivate: [Auth]},
    { path: 'user/:id', component: UserComponent, canActivate: [Auth],
    children:[
      {
      path : 'summary',
      component: UserSummaryComponent
      },
      { 
        path : 'cashflow',
        component: UserCashflowComponent,
        canActivate: [Auth]
      },
      {
        path : 'goals',
      component: UserGoalsComponent
      },
      { 
        path : 'bills',
        component: UserBillsComponent,
      },
      {
        path: 'bill-detail/:billid',
        component: UserBillDetailComponent
      },
      {
        path: "banking",
        component: UserBankingComponent
      },
      {
        path: "settings",
        component: UserSettingsComponent
      },
      {
        path: "appview",
        component: AppviewComponent
      }
    ]
  },
  { path: 'employers', component: EmployersComponent, canActivate: [Auth]},
  { path: 'employer/:id', component: EmployerComponent, canActivate: [Auth],
    children: [
      {
        path : 'summary',
        component: UserSummaryComponent
        },
      { 
        path : 'payroll',
        component: UserCashflowComponent,
        canActivate: [Auth]
      }
    ]
  },
  ]},
  { path: 'batches', component: BatchesComponent},
]
;

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
