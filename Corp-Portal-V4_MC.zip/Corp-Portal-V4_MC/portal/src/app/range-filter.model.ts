export class RangeFilter {
    currentRange: String;
    rangeValue: String;
    rangeSpecific: String;
    rangeBegin;
    rangeEnd;
    id;

    constructor(currentRange: string, rangeValue: string, rangeSpecific: string, rangeBegin, rangeEnd, id) {
        this.currentRange = currentRange;
        this.rangeValue = rangeValue;
        this.rangeSpecific = rangeSpecific;
        this.rangeBegin = rangeBegin;
        this.rangeEnd = rangeEnd;
        this.id = "filter" + id;
    }
}
