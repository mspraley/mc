import { Component, OnInit, Input } from '@angular/core';
import { RangeFilter } from '../range-filter.model';
import { UserService } from '../services/user/user-service.service';
import { Router } from '@angular/router';
import {
  trigger,
  state,
  style,
  animate,
  transition,
  keyframes
} from '@angular/animations';
import { EmployerService } from '../services/employer/employer.service';

@Component({
  selector: 'search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  animations : [
    trigger('flyInOut', [
      state('fade', style({
        opacity: 0,
        "max-height": '0'
      })),
      state('fly',   style({
        opacity: 1,
        "max-height": "5000px"
      })),
      transition('fly => fade', animate('100ms ease-in')),
      transition('fade => fly', animate('100ms ease-out'))
    ])
  ]
})
export class SearchComponent implements OnInit {

  filters = [
    "Bills",
    "Goals",
    "Debts",
    "Completed Goal"
  ]
  rangeFilters = [];
  ranges = [
    {"name" : "Savings amount", "value" : "savings"},
    {"name" : "Age", "value" : "age"},
    {"name" : "Target amount", "value" : "target"},
  ]

  filterID = 0;
  booleanFilters = [];
  filtersShown;
  resultsShown = false;
  searchText = '';
  results = [];
  searchTimeout;
  user;

  @Input() type;

  constructor(private router: Router, private userService: UserService, private employerService: EmployerService) { }

  ngOnInit() {
    this.userService.user.subscribe(user => {
      this.resultsShown = false;
      this.searchText = '';
    });
  }

  toggleBooleanFilter(value) {
    var index = this.booleanFilters.indexOf(value, 0);
    if (index > -1) {
      this.booleanFilters.splice(index, 1);
    } else {
    this.booleanFilters.push(value);
    }
    this.ask(this.searchText);
  }

  ask(value: string) {
    var params = {};
    if (this.type == "user") {
      params = {"email": value, "mcpId": value, "name": value, "match" : "any"};
      if (this.booleanFilters.length > 0) {
        this.booleanFilters.forEach(function(filter){
          params[filter.toLowerCase()] = "1-";
        });
      }
  
      if (this.rangeFilters.length > 0) {
        this.rangeFilters.forEach(function(range: RangeFilter) {
          if (range.rangeSpecific == "exactly") {
            params[range.rangeValue.toString()] = range.rangeBegin;
          }
          params[range.rangeValue.toString()] = range.rangeBegin + "-" + range.rangeEnd;
        });
      }
    } else {
      params = {"name": value};
    }

    if (value.length > 3) {
      clearTimeout(this.searchTimeout)
      this.searchTimeout = setTimeout(() => {
        if (this.type == "user") {
          this.userService.getUsers(params).subscribe(users => {
            this.results = users.payload.data[0].rows.slice(0,5);
            this.resultsShown = true;
          })
        } else {
          this.employerService.getEmployers(params).subscribe(users => {
            this.results = users.payload.data[0].rows.slice(0,5);
            this.resultsShown = true;
          })
        }
      }, 300);
    }
  }

  toggleFiltersShown() {
    this.filtersShown = true;
  }

  addFilter() {
    let range = new RangeFilter("Savings amount", "savings", "between", 0, 100, this.filterID++);
    this.rangeFilters.push(range);
    this.ask(this.searchText);
  }

  removeFilter(value) {
    var index = this.rangeFilters.indexOf(value, 0);
    this.rangeFilters = this.rangeFilters.filter(function( filter ) {
      return filter.id !== value;
    });
    this.ask(this.searchText);
  }

  checkForEnter(event: any) { // without type info
    if (event.key == "Enter") {
      this.ask(this.searchText);
    }
  }
}
