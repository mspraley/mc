import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployerService } from '../services/employer/employer.service';

@Component({
  selector: 'app-employer',
  templateUrl: './employer.component.html',
  styleUrls: ['./employer.component.scss']
})
export class EmployerComponent implements OnInit {

  employerID;
  dataLoaded = false;
  employer;

  constructor(private route: ActivatedRoute, private employerService: EmployerService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.employerID = +params['id'];
      this.dataLoaded = false;

      this.employerService.getEmployer(this.employerID).subscribe(data =>{
      });
   });

   this.employerService.employer.subscribe(employer => {
    this.employer = employer;
    this.dataLoaded = true;
    }, error => {
      localStorage.removeItem('currentUser');
    })
  }

}
