import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mask'
})
export class MaskPipe implements PipeTransform {

  transform(phrase: string): any {
    let toBeReplaced = phrase.slice(0, 7);
    return phrase.replace(toBeReplaced, "xxxxxx");
  }
}
