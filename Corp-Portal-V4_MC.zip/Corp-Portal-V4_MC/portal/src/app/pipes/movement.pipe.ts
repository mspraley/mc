import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'movement',
  pure: false
})
export class MovementPipe implements PipeTransform {
  transform(items: [any], filter: string): any {
    if (filter == "deposits") {
      return items.filter(function(item){
        return item.action == "PULL"
      });
    } else if (filter == "withdrawals") {
      return items.filter(function(item){
        return item.action != "PULL"
      });
    } else {
      return items;
    }

  }
}
