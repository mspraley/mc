import { DeletePipe } from './delete.pipe';

describe('DeletePipe', () => {
  it('create an instance', () => {
    const pipe = new DeletePipe();
    expect(pipe).toBeTruthy();
  });
});
