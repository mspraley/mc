import { MaskPipe } from './mask.pipe';

describe('MaskPipe', () => {
  it('create an instance', () => {
    const pipe = new MaskPipe();
    expect(pipe).toBeTruthy();
  });
});
