import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'activity',
  pure: false
})
export class ActivityPipe implements PipeTransform {

  transform(items: [any], filter: string): any {
    if (filter == '') { 
      return items;
    } else {
      return items.filter(function(item){
        return item.actionType == filter
      });
    }
  }

}
