import { MovementPipe } from './movement.pipe';

describe('MovementPipe', () => {
  it('create an instance', () => {
    const pipe = new MovementPipe();
    expect(pipe).toBeTruthy();
  });
});
