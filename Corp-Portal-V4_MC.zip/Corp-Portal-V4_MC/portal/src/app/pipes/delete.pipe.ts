import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'delete',
  pure: false
})
export class DeletePipe implements PipeTransform {

  transform(items: [any]): any {
      return items.filter(function(item){
        return item.transaction_status != "CORP-REMOVED";
      });
    }
}
