import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { UserSummaryComponent } from './user/user-summary/user-summary.component';
import { AppRoutingModule } from './route/app-routing.module';
import { UserGoalsComponent } from './user/user-goals/user-goals.component';
import { UserBillsComponent } from './user/user-bills/user-bills.component';
import { UserActivityComponent } from './user/user-summary/user-activity/user-activity.component';
import { UserEnrollmentComponent } from './user/user-summary/user-enrollment/user-enrollment.component';
import { UserMetricsComponent } from './user/user-summary/user-metrics/user-metrics.component';
import { UserContactComponent } from './user/user-summary/user-contact/user-contact.component';
import { NavComponent } from './nav/nav.component';
import { UserCashflowComponent } from './user/user-cashflow/user-cashflow.component';
import { UsersComponent } from './users/users.component';
import { BatchesComponent } from './batches/batches.component';
import { BatchComponent } from './batch/batch.component';
import { FusionChartsModule } from 'angular4-fusioncharts';
import * as FusionCharts from 'fusioncharts';
import * as Charts from 'fusioncharts/fusioncharts.charts';
import * as FintTheme from 'fusioncharts/themes/fusioncharts.theme.fint';
import { MetricComponent } from './users/metric/metric.component';
import { MicroMetricComponent } from './users/micro-metric/micro-metric.component';
import { UserBillDetailComponent } from './user/user-bills/user-bill-detail/user-bill-detail.component';
import { UserService } from './services/user/user-service.service';
import { SearchComponent } from './search/search.component';
import { UserBankingComponent } from './user/user-banking/user-banking.component';
import { EmployersComponent } from './employers/employers.component';
import { LoginComponent } from './login/login.component';
import { Auth } from './guards/auth';
import { AuthService } from './services/auth/auth.service';
import { HeaderInterceptor } from './interceptors/header-interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { MaskPipe } from './pipes/mask.pipe';
import { MovementPipe } from './pipes/movement.pipe';
import { UserSettingsComponent } from './user/user-settings/user-settings.component';
import { EmptyComponent } from './shared/empty/empty.component';
import { AppviewComponent } from './user/appview/appview.component';
import { EmployerService } from './services/employer/employer.service';
import { ResultComponent } from './search/result/result.component';
import { EmployerComponent } from './employer/employer.component';
import { ActivityPipe } from './pipes/activity.pipe';
import { DeletePipe } from './pipes/delete.pipe';
import { LedgerService } from './services/ledger/ledger.service';

FusionChartsModule.fcRoot(FusionCharts, Charts, FintTheme);


@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    UserSummaryComponent,
    UserGoalsComponent,
    UserBillsComponent,
    UserActivityComponent,
    UserEnrollmentComponent,
    UserMetricsComponent,
    UserContactComponent,
    NavComponent,
    UserCashflowComponent,
    UsersComponent,
    BatchesComponent,
    BatchComponent,
    MetricComponent,
    MicroMetricComponent,
    UserBillDetailComponent,
    SearchComponent,
    UserBankingComponent,
    EmployersComponent,
    LoginComponent,
    HomeComponent,
    MaskPipe,
    MovementPipe,
    UserSettingsComponent,
    EmptyComponent,
    AppviewComponent,
    ResultComponent,
    EmployerComponent,
    ActivityPipe,
    DeletePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FusionChartsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [LedgerService, UserService, EmployerService, Auth, AuthService, 
    {provide: HTTP_INTERCEPTORS,
    useClass: HeaderInterceptor,
    multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
