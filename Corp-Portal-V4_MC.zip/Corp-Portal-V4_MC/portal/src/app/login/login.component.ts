import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username = '';
  password = '';
  mfaRequire = false;
  step = 1;
  code = '';

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {
  }

  login() {
    this.authService.login(this.username, this.password)
    .subscribe(
        data => {
            console.log(data);
            if (data.payload.data[0].mfa.required) {
              this.mfaRequire = true;
              this.step = 2;
            }
            this.router.navigate(["users"]);
        },
        error => {
          console.log("error logging in");
        });
  }

  mfaLogin() {
    this.authService.mfaLogin(this.code).subscribe(
      data => {
        if (!data.payload.data[0].mfa.required) {
          this.router.navigate(["users"]);
        }
      }
    )
  }

}
