//mock list of users

export const users = [
    {
        "name" : "Jennifer Fancher",
        "email" : "jfancher@gmail.com",
        "mcpID" : "423453"
    }
]