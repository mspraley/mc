import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx'
import { of } from 'rxjs/observable/of';
import { from } from 'rxjs/observable/from';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { map } from 'rxjs/operators';
import { API } from "../api";
  

@Injectable()
export class LedgerService {

  constructor(private http: HttpClient) { }

  public transferSub(mcpId, toId, fromId, amount): Observable<any>  {
    return this.http.post<any>(API.gl.transferSub, {
      amount: amount,
      mcpId : mcpId,
      targetSubAccountId: toId,
      sourceSubAccountId: fromId
    });
  }

  public transferExternal(mcpId, fromId, amount): Observable<any> {
    return this.http.post<any>(API.gl.transferExternal, {
      amount: amount,
      mcpId : mcpId,
      subAccountId: fromId
    });
  }
}
