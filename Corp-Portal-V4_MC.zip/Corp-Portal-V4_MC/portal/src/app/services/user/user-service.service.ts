import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx'
import { of } from 'rxjs/observable/of';
import { from } from 'rxjs/observable/from';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { map } from 'rxjs/operators';
import { API } from "../api";

@Injectable()
export class UserService {


  public user = new ReplaySubject<any>(1);
  public contact = new ReplaySubject<any>(1);
  public enrollment = new ReplaySubject<any>(1);
  public batch = new ReplaySubject<any>(1);
  public ledger = new ReplaySubject<any>(1);
  public bill = new ReplaySubject<any>(1);

  constructor(private http: HttpClient) { }

  public getUsers(params): Observable<any>  {  
    return this.http.post<any>(API.users.searchURL, params);
  }

  public getUser(id): Observable<any> {
    var url = API.users.userURL.replace('{mcpId}', id);
    return this.http.get<any>(url).map(user => {
      this.user.next(user.payload[0]);
    })
  }

  public getUserContact(id) {
    var url = API.users.userContactURL.replace('{mcpId}', id);
    this.http.get<any>(url).subscribe(user => {
      this.contact.next(user.payload.data[0]);
    })
  }

  getEnrollment(id): Observable<any> {
    var url = API.users.enrollmentURL.replace('{mcpId}', id);
    return this.http.get<any>(url).map(data => {
      this.enrollment.next(data.payload.data[0]);
    })
  }

  getBatch(id): Observable<any> {
    var url = API.users.batchURL.replace('{mcpId}', id);
    url = this.getDateRange(url);
    return this.http.get<any>(url).map(data => {
      if (data.payload.data.length) {
        this.batch.next(Object.values(data.payload.data[0]));
      } else {
        this.batch.next([]);
      }
    })
  }

  getLedger(id): Observable<any> {
    var url = API.users.ledgerURL.replace('{mcpId}', id);
    url = this.getDateRange(url);
    return this.http.get<any>(url).map(data => {
      if (data.payload.data.length) {
        this.ledger.next(Object.values(data.payload.data));
      } else {
        this.ledger.next([]);
      }
    })
  }

  deleteBatchItem(batchKey, transactionKey) {
    var url = API.users.batchItemURL.replace('{batchKey}', batchKey);
    url = url.replace('{transactionKey}', transactionKey);
    return this.http.delete<any>(url).map(data => {
      this.batch.next(Object.values(data.payload.data[0]));
    })
  }

  changeBankAccount() {
    //TODO 
  }

  getBillDetail(id, billId) {
    var url = API.users.billDetailURL.replace('{mcpId}', id);
    url = url.replace('{billId}', billId);
    url = this.getYearRange(url);
    this.http.get<any>(url).subscribe(data => {
      this.bill.next(data.payload.data);
    })
  }

  hardClose(id, action): Observable<any> {
    var url = API.users.closeUserURL.replace('{mcpId}', id);
    if (action) {
      return this.http.put(url, {});
    } else {
      return this.http.delete<any>(url);
    }
  }

  getDateRange(url) {
    let today = new Date();
    let lastDate = new Date();
    lastDate.setDate(today.getDate() - 30);
    var startDate = today.getFullYear() + "-" + ("0" + (today.getMonth() + 1)).slice(-2) + "-" + ("0" + today.getUTCDate()).slice(-2);
    var endDate = lastDate.getFullYear() + "-" + ("0" + (lastDate.getMonth() + 1)).slice(-2) + "-" + ("0" + lastDate.getUTCDate()).slice(-2);
    url = url.replace('{startDate}', startDate);
    url = url.replace('{endDate}', endDate);
    return url;
  }

  getYearRange(url) {
    let today = new Date();
    var endDate = (today.getFullYear() - 1) + "-" + ("0" + (today.getMonth() + 1)).slice(-2) + "-" + ("0" + today.getUTCDate()).slice(-2);
    var startDate = today.getFullYear() + "-" + ("0" + (today.getMonth() + 1)).slice(-2) + "-" + ("0" + today.getUTCDate()).slice(-2);
    url = url.replace('{startDate}', startDate);
    url = url.replace('{endDate}', endDate);
    return url;
  }

}
