export const API = {
    URL : {
        development : "https://adminapi3.doublenetpay.com",
        production : "https://adminapi1.doublenetpay.com"
    },
    session : {
        sessionURL : "{base}/session/login",
        mfaURL : "{base}/session/login/response/"
    },
    users : {
        searchURL : "{base}/user/search",
        userURL : "{base}/user/dashboard/mcpId/{mcpId}/refresh/false/return/true",
        userContactURL : "{base}/user/contacts/mcpId/{mcpId}",
        enrollmentURL : "{base}/user/enrollment/mcpId/{mcpId}/employerId",
        batchURL : "{base}/user/batches/mcpId/{mcpId}/from/{endDate}/thru/{startDate}/order/desc",
        batchItemURL : "{base}/batch/entry/batchKey/{batchKey}/transactionKey/{transactionKey}/source/CORE",
        ledgerURL : "{base}/user/ledger/mcpId/{mcpId}/from/{endDate}/thru/{startDate}/order/desc",
        closeUserURL : "{base}/user/close/mcpId/{mcpId}",
        billDetailURL: "{base}/user/bills/mcpId/{mcpId}/from/{endDate}/thru/{startDate}/order/desc/masterBillId/{billId}"
    },
    employers : {
        searchURL : "{base}/employers/search",
        employerURL : "{base}/employers/info/employerId/{employerId}"
    },
    appview : {
        appviewURL : "{base}/session/appview/mcpId/{mcpId}/token/{token}" 
    },
    gl : {
        transferSub : "{base}/gl/transfer",
        transferExternal: "{base}/gl/withdraw"
    }
}