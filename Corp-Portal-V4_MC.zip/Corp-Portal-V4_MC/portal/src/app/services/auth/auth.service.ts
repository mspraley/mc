import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import { API } from "../api";

 
@Injectable()
export class AuthService {

  
    constructor(private http: HttpClient) { }
 
    login(username: string, password: string) {
        return this.http.post<any>(API.session.sessionURL, { user: username, password: password }) 
 
            .map(user => {
                if (!user.payload.data[0].mfa.required) {
                    localStorage.setItem('dnpAuth', user.payload.data[0].token);
                    localStorage.setItem('currentUser', JSON.stringify(user));
                    setTimeout(() => {
                        localStorage.removeItem('currentUser');
                    }, 3600000)
                    
                    return user;
                }
                if (user) {
                  localStorage.removeItem('currentUser');
                  localStorage.setItem('dnpAuth', user.payload.data[0].token);
                }
 
                return user
            });
    }

    mfaLogin(code: string) {
      return this.http.put<any>(API.session.mfaURL + code, {})
      .map(user => {
        if (!user.payload.data[0].mfa.required) {
            localStorage.setItem('currentUser', JSON.stringify(user));
        }

          return user;
      });
    }
 
    logout() {
        localStorage.removeItem('currentUser');
    }
}