import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx'
import { of } from 'rxjs/observable/of';
import { from } from 'rxjs/observable/from';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { map } from 'rxjs/operators';
import { API } from "../api";

@Injectable()
export class EmployerService {

  public employer = new ReplaySubject<any>(1);

  constructor(private http: HttpClient) { }

  public getEmployers(params): Observable<any>  {  
    return this.http.post<any>(API.employers.searchURL, params);
  }

  public getEmployer(id): Observable<any>  {
    var url = API.employers.employerURL.replace('{employerId}', id);
    return this.http.get<any>(url).map(employer => {
      this.employer.next(employer.payload.data[0]);
    })
  }

}
