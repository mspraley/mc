# Corp-Portal-V4
The new "real" corp portal by Mat

# Development Instructions
Angular 5
- Download angular cli (https://cli.angular.io/)
- Run "ng serve" inside /portal
- Go to localhost:4200 in your browser


